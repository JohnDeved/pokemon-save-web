# mGBA Prebuilt Binary for Docker Environment

This package contains a prebuilt mGBA binary with Qt5 frontend and Lua scripting support, specifically built for the pokemon-save-web Docker environment.

## Contents

- `mgba-qt` - mGBA Qt frontend binary
- `libmgba.so.0.11` - mGBA shared library
- `mgba-qt-wrapper.sh` - Wrapper script that sets library path
- `README.md` - This file

## Features

✅ **Qt5 Frontend** - Full GUI support with headless capability  
✅ **Lua Scripting** - Complete Lua 5.4 integration with socket API  
✅ **--script Support** - Command line argument for loading Lua scripts  
✅ **GBA/GB Support** - Game Boy Advance and Game Boy emulation  
✅ **Savestate Loading** - Load memory savestates via --savestate argument  

## Usage

Use the wrapper script to ensure proper library linking:

```bash
# Launch with a Lua script and savestate
./mgba-qt-wrapper.sh --script http-server.lua --savestate emerald.ss0 emerald.gba

# Check available options
./mgba-qt-wrapper.sh --help
```

## Build Information

**Built from:** mGBA master branch (latest)  
**Build date:** July 27, 2024  
**Platform:** Linux x86_64 (Ubuntu 24.04)  
**Compiler:** GCC 13.3.0  

**Build configuration:**
```
cmake -B build \
  -DBUILD_QT=ON \
  -DBUILD_SDL=OFF \
  -DUSE_LUA=ON \
  -DCMAKE_BUILD_TYPE=Release \
  -DUSE_FFMPEG=OFF \
  -DUSE_MINIZIP=OFF \
  -DUSE_LIBZIP=OFF \
  -DUSE_DISCORD_RPC=OFF
```

## Dependencies

This binary requires the following system libraries (available in Ubuntu 22.04+):

- Qt5 libraries (qtbase5, qtmultimedia5)
- Lua 5.4
- OpenGL/EGL libraries
- Standard system libraries (libc, libstdc++, etc.)

## Docker Integration

This prebuilt binary is designed for use in the pokemon-save-web Docker environment. It automatically:

1. Downloads at build time from GitHub releases
2. Falls back to source compilation if download fails
3. Provides the same functionality as a full source build
4. Reduces Docker build time from 4-5 minutes to 10-30 seconds

## Testing

To verify the binary works correctly:

```bash
# Test basic functionality
./mgba-qt-wrapper.sh --help

# Test script support
./mgba-qt-wrapper.sh --help | grep script
# Should output: --script FILE  Run a script on start. Can be passed multiple times
```

## License

This binary is built from mGBA source code which is available under the Mozilla Public License 2.0.
Source code: https://github.com/mgba-emu/mgba

## Support

For issues with this prebuilt binary, refer to the pokemon-save-web project:
https://github.com/JohnDeved/pokemon-save-web

For mGBA-related issues, refer to the official mGBA project:
https://github.com/mgba-emu/mgba